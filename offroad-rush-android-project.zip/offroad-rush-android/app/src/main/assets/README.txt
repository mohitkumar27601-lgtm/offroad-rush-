OFFROAD RUSH - PWA package
==========================
Files:
  index.html      - the game
  manifest.json   - app name, icon, fullscreen + landscape
  sw.js           - offline support (service worker)
  icons/          - app icons

How to put it online (free) - Netlify Drop:
  1. Open https://app.netlify.com/drop in Chrome
  2. Drag this WHOLE folder (offroad-rush-pwa) onto the page
  3. You get a link like https://something.netlify.app
  4. Open that link on your phone in Chrome -> menu (3 dots) -> Install app / Add to Home screen

Important: the site must open with https:// (Netlify/GitHub Pages/Cloudflare Pages all do this).
To update the game later: upload the folder again and change CACHE='offroad-rush-v1' to v2 in sw.js.
