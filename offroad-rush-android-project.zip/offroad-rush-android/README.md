# Offroad Rush Android project

This is an Android Studio project wrapping the supplied Offroad Rush PWA in a fullscreen, landscape WebView. Game files are bundled in `app/src/main/assets`, so the game content does not need a website or internet connection.

## Build the APK
1. Install Android Studio (with Android SDK Platform 35).
2. Open this `OffroadRush` folder in Android Studio.
3. Allow Gradle sync to finish (internet is needed once to download Android Gradle Plugin and AndroidX WebKit).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

App ID: `com.offroadrush.game`  
Orientation: landscape  
Display: fullscreen  
Game assets: bundled locally
